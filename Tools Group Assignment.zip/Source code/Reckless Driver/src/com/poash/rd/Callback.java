package com.poash.rd;

@FunctionalInterface
public interface Callback {
	SideObject Create() ;
}
