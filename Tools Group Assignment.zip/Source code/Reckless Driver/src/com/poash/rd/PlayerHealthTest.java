package com.poash.rd;
import static org.junit.Assert.*;

import org.junit.Test;

public class PlayerHealthTest {

	@Test
	public void GetPlayerStatetest() {
		
		int healthUnit1 = 75;
		int healthUnit2 = 50;
		int healthUnit3 = 15;
		int healthUnit4 = 0;
		
		PlayerHealth ph = new PlayerHealth();
		ph.SetUnits(healthUnit1);
		assertEquals(PlayerState.HEALTHY, ph.GetPlayerState());
		
		ph.SetUnits(healthUnit2);
		assertEquals(PlayerState.INJURED, ph.GetPlayerState());
		
		ph.SetUnits(healthUnit3);
		assertEquals(PlayerState.CRITICAL, ph.GetPlayerState());
		
		ph.SetUnits(healthUnit4);
		assertEquals(PlayerState.DEAD, ph.GetPlayerState());
		
	}

}
